# -*- coding: utf-8 -*-
"-------------------------------------------------------------------------------------------------"
"""
2D_Visual_Transformer_MRI_SR Reconstruction. TTSRMRI.
This is the code for "Visual Transformer based Network" for MRI SR Reconstruction. The 2D_Visual_Transformer_MRI_SR is modified from the TTSR which was original proposed 
in paper:
"2020.Learning Texture Transformer Network for Image Super-Resolution"
(https://arxiv.org/abs/2006.04139)
accepted in CVPR 2020.

** The basic idea of 2D_Visual_Transformer_MRI_SR is, .
"""
"""
Author: chisyliu@hotmail.com *
        hao.li@med.uni-heidelberg.de *
        
        * Both authors contribute equally
Version: 1.0.0
"""
"-------------------------------------------------------------------------------------------------"


from option import args
from utils import mkExpDir
from dataset import dataloader
from model import TTSR
from loss.loss import get_loss_dict
from trainer import Trainer

import os
import torch
import warnings
warnings.filterwarnings('ignore')


if __name__ == '__main__':
    ### make save_dir where save all the output.
    _logger = mkExpDir(args)

    ### dataloader of training set and testing set, if it is NOT in test mode(args.test == True stands for test mode).
    _dataloader = dataloader.get_dataloader(args) if (not args.test) else None

    ### get device and load model into device.
    device = torch.device('cpu' if args.cpu else 'cuda')
    _model = TTSR.TTSR(args).to(device)
    
    ### load the model into more than one gpu if have more than one gpu.
    if ((not args.cpu) and (args.num_gpu > 1)):
        _model = nn.DataParallel(_model, list(range(args.num_gpu)))

    ### create loss function.
    _loss_all = get_loss_dict(args, _logger)

    ### create trainer.
    t = Trainer(args, _logger, _dataloader, _model, _loss_all)

    ### training / testing / eval the model.
    if (args.test):
        t.load(model_path=args.model_path)
        t.test()
    elif (args.eval):
        t.load(model_path=args.model_path)
        t.evaluate()
    else:
        for epoch in range(1, args.num_init_epochs+1):
            t.train(current_epoch=epoch, is_init=True)
        for epoch in range(1, args.num_epochs+1):
            t.train(current_epoch=epoch, is_init=False)
            if (epoch % args.val_every == 0):
                t.evaluate(current_epoch=epoch)
